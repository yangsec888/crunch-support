################################################################################
#  Python Package to Support 42crunch System Deployment
#
#    Author: Sam Li <yang.li@owasp.org>
#
#       2022 - 2023
################################################################################
import unittest
from crunch_support.token_services import *

class TestTokenService(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass